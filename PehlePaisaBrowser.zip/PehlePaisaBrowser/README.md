# Datapay - Charan 1

1. Android Studio (Koala ya naya) mein File > Open se is folder ko kholo.
2. Gradle sync hone do (internet chahiye). Update ka sawal aaye to Yes karo.
3. Phone mein USB debugging chalu karke Run (hara triangle) dabao.

Charan 1 mein: tabs, address bar, tracker block (assets/blocklist.txt), third-party cookies band,
home par common sites, aur http/https links ke liye default browser banne ka option.
Abhi isme wallet, data requests aur kamai nahi hai. Wo Charan 2 aur 3 mein aayenge.
