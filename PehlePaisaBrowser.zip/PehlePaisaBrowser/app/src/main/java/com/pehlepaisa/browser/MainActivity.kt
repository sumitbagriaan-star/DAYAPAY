package com.pehlepaisa.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.ByteArrayInputStream
import java.net.URLEncoder

class MainActivity : Activity() {
    private val tabs = ArrayList<WebView>()
    private var cur = 0
    private var blocked = 0
    private val blockHosts = HashSet<String>()
    private lateinit var holder: FrameLayout
    private lateinit var urlBox: EditText
    private lateinit var shield: TextView
    private lateinit var home: ScrollView

    private val sites = listOf(
        Triple("Facebook", "https://m.facebook.com", "#1877F2"),
        Triple("Instagram", "https://www.instagram.com", "#C13584"),
        Triple("YouTube", "https://m.youtube.com", "#E02D2D"),
        Triple("WhatsApp", "https://web.whatsapp.com", "#1FA855"),
        Triple("Google", "https://www.google.com", "#4A7BF0"),
        Triple("Amazon", "https://www.amazon.in", "#E18B0A"),
        Triple("Flipkart", "https://www.flipkart.com", "#2874F0"),
        Triple("PhonePe", "https://www.phonepe.com", "#5F259F"),
        Triple("Netflix", "https://www.netflix.com", "#C4111D")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assets.open("blocklist.txt").bufferedReader().useLines { lines ->
            lines.map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .forEach { blockHosts.add(it) }
        }
        setContentView(buildUi())
        newTab(intent?.data?.toString())
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.toString()?.let { newTab(it) }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F1F4EE"))
        }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        urlBox = EditText(this).apply {
            hint = "Search ya address likho"
            isSingleLine = true
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { go(text.toString()); true } else false
            }
        }
        top.addView(urlBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        shield = TextView(this).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1B7A58"))
        }
        top.addView(shield)

        holder = FrameLayout(this)
        home = buildHome()

        val bottom = LinearLayout(this)
        fun btn(label: String, action: () -> Unit) {
            bottom.addView(
                Button(this).apply { text = label; setOnClickListener { action() } },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        btn("<") { val w = tabs[cur]; if (w.tag != null && w.canGoBack()) w.goBack() }
        btn(">") { val w = tabs[cur]; if (w.tag != null && w.canGoForward()) w.goForward() }
        btn("Home") { tabs[cur].tag = null; show(cur) }
        btn("Tabs") { tabDialog() }
        btn("Reload") { val w = tabs[cur]; if (w.tag != null) w.reload() }

        root.addView(top)
        root.addView(holder, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottom)
        return root
    }

    private fun buildHome(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        col.addView(TextView(this).apply {
            text = "Aapka data, aapki keemat."
            textSize = 24f
            setTextColor(Color.parseColor("#14281F"))
        })
        col.addView(TextView(this).apply {
            text = "Tracker yahan rukte hain. Neeche se koi site kholo."
            setPadding(0, dp(4), 0, dp(12))
        })
        val grid = GridLayout(this).apply { columnCount = 3 }
        sites.forEach { (name, url, color) ->
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(80)
                setMargins(dp(4), dp(4), dp(4), dp(4))
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            grid.addView(Button(this).apply {
                text = name
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor(color))
                setOnClickListener { go(url) }
            }, lp)
        }
        col.addView(grid)
        return ScrollView(this).apply { addView(col) }
    }

    private fun newTab(url: String?) {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false)
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (isTracker(r.url.host)) {
                    blocked++
                    runOnUiThread { updateShield() }
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun onPageStarted(v: WebView, u: String?, f: android.graphics.Bitmap?) {
                if (tabs.getOrNull(cur) === v) urlBox.setText(u ?: "")
            }
        }
        tabs.add(w)
        show(tabs.size - 1)
        if (url != null) go(url)
    }

    private fun isTracker(host: String?): Boolean {
        var h = host ?: return false
        while (true) {
            if (blockHosts.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    private fun go(input: String) {
        val s = input.trim()
        if (s.isEmpty()) return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ") -> "https://$s"
            else -> "https://duckduckgo.com/?q=" + URLEncoder.encode(s, "UTF-8")
        }
        val w = tabs[cur]
        w.tag = true
        show(cur)
        w.loadUrl(url)
    }

    private fun show(i: Int) {
        cur = i
        holder.removeAllViews()
        val w = tabs[i]
        if (w.tag == null) {
            holder.addView(home)
            urlBox.setText("")
        } else {
            holder.addView(w)
            urlBox.setText(w.url ?: "")
        }
        updateShield()
    }

    private fun updateShield() {
        shield.text = "Shield: %,d roke".format(blocked)
    }

    private fun tabDialog() {
        val names = tabs.map { it.title?.takeIf { t -> t.isNotBlank() } ?: "Naya tab" } +
            listOf("+ Naya tab", "Ye tab band karo")
        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setItems(names.toTypedArray()) { _, i ->
                when {
                    i < tabs.size -> show(i)
                    i == tabs.size -> newTab(null)
                    else -> closeTab()
                }
            }.show()
    }

    private fun closeTab() {
        if (tabs.size == 1) { tabs[0].tag = null; show(0); return }
        tabs[cur].destroy()
        tabs.removeAt(cur)
        show(minOf(cur, tabs.size - 1))
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val w = tabs[cur]
        when {
            w.tag != null && w.canGoBack() -> w.goBack()
            w.tag != null -> { w.tag = null; show(cur) }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        tabs.forEach { it.destroy() }
        super.onDestroy()
    }
}
